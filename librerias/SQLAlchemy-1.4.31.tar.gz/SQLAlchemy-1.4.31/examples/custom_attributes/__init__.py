"""
Examples illustrating modifications to SQLAlchemy's attribute management
system.

.. autosource::

"""
